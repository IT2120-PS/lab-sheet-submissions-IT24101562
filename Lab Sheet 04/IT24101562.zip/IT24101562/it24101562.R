setwd("C:\\Users\\it24101562\\Desktop\\IT24101562")
branch_data <- read.table("Exercise.txt" , header =TRUE , sep = ",")
fix(branch_data)
attach(branch_data)
str(branch_data)
#obtain the boxplot
boxplot(branch_data$Sales_X1,main = "Boxplot for sales", ylab = "sales")
#five number summary
summary(Advertising_X2)
#IQR
IQR(Advertising_X2)
#q5
get.ouliers <-function(z){
  q1 <- quantile(z) [2]
  q3 <- quantile(z) [4]
  iqr <- q3 - q1
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  print(paste ("upper bound = , ub"))
  print(paste ("lower bound = , lb"))
  print(paste ("outliers:",paste(sort (z[z<lb|z>ub]),collapse = ",")))
}
